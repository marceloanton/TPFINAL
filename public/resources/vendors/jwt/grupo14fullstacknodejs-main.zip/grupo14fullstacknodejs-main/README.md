# grupo14fullstacknodejs

Estas practicas se realizaron por el Grupo 14 del curso de FullStack con NodeJS del programa Codo a Codo

## **WEB**

- Web con vista a los contenidos: **[Grupo 14](https://marceloanton.github.io/grupo14fullstacknodejs/)**

## Table of Contents

- [**Project Description**](#project-description)
- [**Installation**](#installation)
- [**Usage**](#usage)
- [**Contributing**](#contributing)
- [**License**](#license)

## Project Description

- Estos proyectos son practicas del curso de Fullstack con NodeJS de Codo a Codo
  - Trabajo Final FrontEnd con API NodeJS

## Installation

- En el caso del TPO 6 debes tener instalada las uientes dependencias de [NodeJS v20.14LTS](https://nodejs.org/en)+
  - `npm i express express-session dotenv mysql2 muller bcryptjs jsonwebtoken `

## Usage

- Estos proyectos son practicas del curso de Fullstack con NodeJS de Codo a Codo

## Contributing

**[Marcelo Anton](https://github.com/marceloanton)**

## License

- You can find the license text in the [LICENSE](LICENSE) file.
