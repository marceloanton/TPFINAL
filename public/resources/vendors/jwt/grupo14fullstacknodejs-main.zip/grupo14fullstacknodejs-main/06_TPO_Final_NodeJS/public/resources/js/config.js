// configuración de nuestra api
const config = {
    apiUrl: 'http://localhost:3000/api'
};

export default config;
