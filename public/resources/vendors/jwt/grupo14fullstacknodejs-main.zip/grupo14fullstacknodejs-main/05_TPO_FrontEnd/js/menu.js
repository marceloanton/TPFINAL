/* Boton para mostrar y ocultar el menu */
function toggleMenu() {
    const menu = document.querySelector('.menu');
    menu.classList.toggle('show');
}